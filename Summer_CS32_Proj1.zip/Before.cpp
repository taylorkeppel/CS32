#include "Before.h"
using namespace std;

Before::Before(int nRows, int nCols)
{
	m_rows = nRows;
	m_cols = nCols; //constructing a basic arena
	for (int i = 0; i < m_rows; i++)
	{
		for (int j = 0; j < m_cols; j++)
		{
			map[i][j] = 0;//maps it out to all null
		}
	}
}
bool Before::keepTrack(int r, int c)
{
	if (r > m_rows || c > m_cols || r <= 0 || c <= 0) //checks to make sure it is in bounds
	{
		return false; //if not, return false
	}
	else
	{
		map[r - 1][c - 1] += 1; //records a one to where player is
		return true; //is in bounds!!
	}
}
void Before::printWhatWasBefore() const
{
	char grid[MAXROWS][MAXCOLS]; //sets up the  max grid to size down from 
	for (int r = 0; r < m_rows; r++)
	{
		for (int c = 0; c < m_cols; c++)
		{
			int i = map[r][c]; //put in all of the rows and columns
			switch (i)
			{
			case 0: grid[r][c] = '.'; //if they've never been there, its a .
				break;
			case 1: grid[r][c] = 'A';
				break;
			case 2: grid[r][c] = 'B';
				break;
			case 3: grid[r][c] = 'C';
				break;
			case 4: grid[r][c] = 'D';
				break;
			case 5: grid[r][c] = 'E';
				break;
			case 6: grid[r][c] = 'F';
				break;
			case 7: grid[r][c] = 'G';
				break;
			case 8: grid[r][c] = 'H';
				break;
			case 9: grid[r][c] = 'I';
				break;
			case 10: grid[r][c] = 'J';
				break;
			case 11: grid[r][c] = 'K';
				break;
			case 12: grid[r][c] = 'L';
				break;
			case 13: grid[r][c] = 'M';
				break;
			case 14: grid[r][c] = 'N';
				break;
			case 15: grid[r][c] = 'O';
				break;
			case 16: grid[r][c] = 'P';
				break;
			case 17: grid[r][c] = 'Q';
				break;
			case 18: grid[r][c] = 'R';
				break;
			case 19: grid[r][c] = 'S';
				break;
			case 20: grid[r][c] = 'T';
				break;
			case 21: grid[r][c] = 'U';
				break;
			case 22: grid[r][c] = 'V';
				break;
			case 23: grid[r][c] = 'W';
				break;
			case 24: grid[r][c] = 'X';
				break;
			case 25: grid[r][c] = 'Y';
				break;
			default: grid[r][c] = 'Z'; 
				break;
			}//a terrible method of doing it tbh but I couldn't think of anything else...
		}

	}
	clearScreen();
	for (int r = 0; r < m_rows; r++)
	{
		for (int c = 0; c < m_cols; c++)
		{
			cout << grid[r][c]; //display the new grid with dots and alphabet
		}
		cout << endl; //new line for the rows
	}
	cout << endl;
}