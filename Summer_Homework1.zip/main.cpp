#include "LinkedList.h"
#include <cassert>
using namespace std;

int main()
{
	
	LinkedList ls;
	ls.insertToFront("Steve");
	ls.insertToFront("Judy");
	ls.insertToFront("Laura");
	ls.insertToFront("Eddie");
	ls.insertToFront("Hariette");
	ls.insertToFront("Carl");
	for (int k = 0; k < ls.size(); k++)
	{
		string x;
		ls.get(k, x);
		cout << x << endl;
	}
	LinkedList ls1;
	ls1.insertToFront("Eric");
	ls1.insertToFront("Shawn");
	ls1.insertToFront("Topanga");
	ls1.insertToFront("Cory");
	ls1.printList();
	ls1.printReverse();	LinkedList e1;
	e1.insertToFront("bell");
	e1.insertToFront("biv");
	e1.insertToFront("devoe");
	LinkedList e2;
	e2.insertToFront("Andre");
	e2.insertToFront("Big Boi");
	e1.append(e2); // adds contents of e2 to the end of e1
	string s;
	assert(e1.size() == 5 && e1.get(3, s) && s == "Big Boi");
	assert(e2.size() == 2 && e2.get(1, s) && s == "Andre");	LinkedList e3;
	e3.insertToFront("Sam");
	e3.insertToFront("Carla");
	e3.insertToFront("Cliff");
	e3.insertToFront("Norm");
	e3.printList();
	e3.reverseList(); // reverses the contents of e1
	string p;
	assert(e3.size() == 4 && e3.get(0, p) && p == "Sam");
	e3.printList();
	LinkedList hello;
	hello.insertToFront("A");
    hello.insertToFront("B");
    hello.insertToFront("C");
	hello.insertToFront("D");
	LinkedList hey;
	hey.insertToFront("X");
	hey.insertToFront("Y");
	hey.insertToFront("Z");
	hello.swap(hey); // exchange contents of e1 and e2
	string pi;
	assert(hello.size() == 3 && hello.get(0, pi) && pi == "Z");
	assert(hey.size() == 4 && hey.get(2, pi) && pi == "B");
	cout << "all done!!!" << endl;
	return 0;
}