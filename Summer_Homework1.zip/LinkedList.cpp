#include "LinkedList.h"
using namespace std;

// copy constructor
LinkedList::LinkedList(const LinkedList& rhs)
{
	Node* temp = rhs.head;
	head = new Node; //allocates the new node as the head
	head->value = temp->value;
	Node *p = nullptr;
	head->next = nullptr;
	p = head;
	m_size = rhs.m_size;
	temp = temp->next;
	while (temp != nullptr)
	{
		p->next = new Node;
		p = p->next;
		p->value = temp->value;
		temp = temp->next;
	}
	p->next = nullptr; //the next has to be a null ptr to prevent them from going out of bounds

}

// Destroys all the dynamically allocated memory
// in the list.
LinkedList::~LinkedList()
{
	Node *p;
	p = head;
	while (p != nullptr)
	{
		Node *n = p->next;
		delete p;
		p = n; //simple destructor that can go through it all
	}
}

// assignment operator
const LinkedList& LinkedList::operator=(const LinkedList& rhs)
{
	if (&rhs == this)
	{
		return *this;
	}
	/*LinkedList temp(rhs);
	swap(temp);
	return *this;*/ //didn't work originally 

		Node *curr, *nextNode; //needs multiple pointers

		curr = head; 
		nextNode = nullptr;

		while (curr)
		{
			nextNode = curr->next;
			delete curr;
			curr = nextNode;
		}

		Node *cptr = new Node;
		cptr = rhs.head;
		cptr->next = NULL;

		Node *temp = rhs.head->next;
		while (temp)
		{
			cptr->next = new Node;
			cptr->next = temp;
			cptr = cptr->next;
			cptr->next = NULL;

			temp = rhs.head->next;
		}

	return *this;
}

// Inserts val  at the front of the list
void LinkedList::insertToFront(const ItemType &val)
{
	m_size += 1;
	Node *p;
	p = new Node;
	p->value = val;
	p->next = head;
	head = p;
}

// Prints the LinkedList
void LinkedList::printList() const
{
	Node *p;
	p = head;
	while (p != nullptr)
	{
		cout << p->value;
		cout << " ";
		if (p->next == nullptr)
			cout << "" << endl;
		p = p->next;
	}
}

// Sets item to the value at position i in this
// LinkedList and return true, returns false if // there is no element i
bool LinkedList::get(int i, ItemType& item) const
{
	if (i >= m_size)
	{
		return false;
	}
	else
	{
		int counter = 0;
		Node*p;
		p = head;
		while (counter != i)
		{
			p = p->next;
			counter++;
		}
		item = p->value;
		return true;
	}
}

// Reverses the LinkedList
void LinkedList::reverseList()
{
	Node *n = head->next; //its the next node pretty much
	Node *p = head;
	p->next = nullptr; 
	while (n != nullptr)
	{
		Node* temp = n;//we set a temp to the nect
		n = n->next; //now traverse
		temp->next = p; //p is the next
		p = temp; //set it equal to p
	}
	head = p; //finally switch it at the end
}

// Prints the LinkedList in reverse order
void LinkedList::printReverse() const
{
	int counter = m_size;
	int ticker = 1; //sets variables for us to use in the while loop
	while (counter != 0)
	{
		Node *p;
		p = head; //sets a head
		int woo = 0;
		while (woo != m_size-ticker) //go to the last with decrementing size
		{
			p = p->next;
			woo++;
		}
		cout << p->value;
		cout << " ";
		if (counter == 1)
		{
			cout << "" << endl;
		}
		ticker++;
		counter--;
	}
  /*Node *n = head->next;
	Node *p = head;
	p->next = nullptr;
	while (n != nullptr)
	{
		Node* temp = n;
		n = n->next;
		temp->next = p;
		p = temp;
	}
	while (p != nullptr)
	{
		cout << p->value;
		cout << " ";
		if (p->next == nullptr)
			cout << "" << endl;
		p = p->next;
	}*/


}

// Appends the values of other onto the end of this
// LinkedList.
void LinkedList::append(const LinkedList &other)
{
	
	Node *p;
	p = head;
	while (p->next != nullptr)
	{
		p= p->next; 
	} //get to the end of the list
	m_size += other.m_size; //add to the size to be accurate
	Node* temp = other.head;
	while (temp != nullptr)
	{
		p->next = new Node;
		p = p->next;
		p->value = temp->value;
		temp = temp->next;
		p->next = nullptr;
	}
}

// Exchange the contents of this LinkedList with the other
// one.
void LinkedList::swap(LinkedList &other)
{
	Node* temp_head = other.head;
	other.head = head;
	head = temp_head;
	
	int temp_size = other.m_size;
	other.m_size = m_size;
	m_size = temp_size; //simple shallow copy
}

// Returns the number of items in the Linked List.
int LinkedList::size() const
{
	return m_size; //getter
}