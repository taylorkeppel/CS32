#include <iostream>
#include <fstream>
#include <istream>
#include <cstring>
#include <string>
#include <cassert>
using namespace std;

const int MAXRESULTS = 20;    // Max matches that can be found
const int MAXDICTWORDS = 30000; // Max words that can be read in

int loadWords(istream &dictfile, string dict[])
{
	if (dict->size() > MAXDICTWORDS) //means we need to quit
	{
		return 0;
	}
	if (dictfile >> dict[0]) //read it in
	{
		return 1 + loadWords(dictfile, dict + 1); //successful insertion and add to our total returned by recursion
	}
	return 0; //if we couldn't insert it :(
}


int recBlends(string word, const string dict[], int size, string
	results[])
{
	int returnthis = 0; //int created for pass by reference to count amount of insertions into results
	int Permutations(string passed, string nonpassed, const string dict[], int size, string
		results[], int &returnthis); //define the function
	return Permutations(word, "", dict, size, results, returnthis); //call it! Our helper :)

}

void showResults(const string results[], int size)
{
	if (size == 0) //means we are done with all of results
	{
		return;
	}
	cout << results[0] << endl; //displays the word in the style of the spec
	return showResults(results + 1, size - 1); //uses recursion to go through all elements
}

int Loop(string passed, string nonpassed, int initvalue, int maxvalue, const string dict[], int size, string
	results[], int &returnthis) //first loop created instead of for loop for permutation code
{
	if (initvalue >= maxvalue)
	{
		return 0; //done looping through
	}
	int Permutations(string passed, string nonpassed, const string dict[], int size, string
		results[], int &returnthis); //define temp
	char c = passed[initvalue]; //knows what we want as our first character
	nonpassed += c; //all permutations starting with c
	passed.erase(initvalue, 1); //erase it 
	Permutations(passed, nonpassed, dict, size, results, returnthis); //add or not
	passed.insert(initvalue, 1, c);// unchoosing
	nonpassed.erase(nonpassed.size() - 1, 1);
	if (results[0] == "")//we need results to be empty to insert the next one
		Loop(passed, nonpassed, initvalue + 1, maxvalue, dict, size, results, returnthis);
	else
		Loop(passed, nonpassed, initvalue + 1, maxvalue, dict, size, results + 1, returnthis);
	return 0; //so it doesnt complain about not all paths return a value
}

bool Loop2(string str, const string dict[], int dict_size)
{
	if (dict_size == 0)
	{
		return false; //not in
	}
	if (str == dict[0]) //matches dict
	{
		return true;
	}
	if (Loop2(str, dict + 1, dict_size - 1)) //benefit of doubt
	{
		return true;
	}
	return false; //def not in
}
bool loop3(string str, string results[])
{
	if (str == results[0])
	{
		return false; //it is in and thats sad
	}
	if (results[0] == "")
	{
		return true; //hooray it's not in
	}
	if (loop3(str, results + 1))
	{
		return true; //benefit of the doubt
	}
	return false; //its in indeed
}

int Permutations(string passed, string nonpassed, const string dict[], int size, string
	results[], int &returnthis)
{
	if (passed.empty()) //means we have a permutation!!! WOOP
	{
		//cout << nonpassed << endl;
		if (Loop2(nonpassed, dict, size) == true) //is in the dictionary
		{
			int blah = returnthis;
			if (loop3(nonpassed, results-blah) == true) //isn't a repeat
			{
				if (returnthis >= MAXRESULTS)
				{
					return returnthis;
				}
				returnthis++; //adds to value we return
				if (results[0] != "")
				{
					results += 1;// need to input at a blank space
					if (results[0] != "")
					{
						results += 1;// This is just about the most inefficient way to do it
						if (results[0] != "")
						{
							results += 1;// but I needed a way to make sure no inputs were overwriting the others
							if (results[0] != "")
							{
								results += 1;// covers it until about 20 matches
								if (results[0] != "")
								{
									results += 1;// need to input at a blank space
									if (results[0] != "")
									{
										results += 1;// need to input at a blank space
										if (results[0] != "")
										{
											results += 1;// need to input at a blank space
											if (results[0] != "")
											{
												results += 1;// need to input at a blank space
												if (results[0] != "")
												{
													results += 1;// need to input at a blank space
													if (results[0] != "")
													{
														results += 1;// need to input at a blank space
														if (results[0] != "")
														{
															results += 1;// need to input at a blank space
															if (results[0] != "")
															{
																results += 1;// need to input at a blank space
																if (results[0] != "")
																{
																	results += 1;// need to input at a blank space
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}

				results[0] = nonpassed; //set it in!
				Loop(passed, nonpassed, 0, passed.length(), dict, size, results + 1, returnthis); //go back in the other function
			}
		}
	}
	else
	{
		int Loop(string passed, string nonpassed, int initvalue, int maxvalue, const string dict[], int size, string
			results[], int &returnthis);
		Loop(passed, nonpassed, 0, passed.length(), dict, size, results, returnthis);
	}
	return returnthis; //returns the number at the end of everything
}





int main()
{
	string results[MAXRESULTS];
	string dict[MAXDICTWORDS];
	ifstream dictfile;         // file containing the list of words
	int nwords;                // number of words read from dictionary
	string word;

	dictfile.open("words.txt");
	if (!dictfile) {
		cout << "File not found!" << endl;
		return (1);
	}

	nwords = loadWords(dictfile, dict);
	cout << nwords << endl;
	cout << "Please enter a string for an anagram: ";
	cin >> word;

	int numMatches = recBlends(word, dict, nwords, results);
	cout << numMatches << endl;
	if (!numMatches)
		cout << "No matches found" << endl;
	else
		showResults(results, numMatches);


	//Permutations(word, "", dict, nwords, results);

}