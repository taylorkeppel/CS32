#ifndef ACTOR_H_
#define ACTOR_H_

#include "GraphObject.h"
#include "GameController.h"

class StudentWorld;

class Actor : public GraphObject
{
public:
	Actor(int x, int y, int id, unsigned int depth, double size, Direction direction, int health);
	virtual ~Actor();
	virtual void doSomething() = 0;
	virtual int identifier(); //0
	void setDead();
	int getHealth() const;
	bool isAlive();
	int getTickTick();
	void resetTick();
	void decreaseTick();
	void stunMe();
	virtual void getAnnoyed();
	void takeHit();
	void takeHitTunneler();
	bool IamDone();
	void changeDone();
private:
		int m_health;
		int ticktick;
		bool done;
};

class AliveActor : public Actor {
public:
	AliveActor(int x, int y, int id, unsigned int depth, double size, Direction direction, StudentWorld* world, int health);
	virtual ~AliveActor();
	StudentWorld* getWorld() const;
private:
	StudentWorld* m_world;
};
class Protester : public AliveActor {
public:
	Protester(StudentWorld* world, int id);
	~Protester();
	virtual void doSomething();
	virtual int identifier(); //4
	void takeSteps(Direction dir);
	bool isValidStep(Direction dir);
	virtual void getAnnoyed();
	int mStateGetter();
private:
	int howManySquaresLeft();
	int howLongShouldIDoThis;
	Direction randomDirection();
	Direction dir;
	int m_state; //0 is startup, 1 is actual regular gameplay, 2 is annoyed/dead
	bool leaveTheEarth;
	bool StartUp;
	bool specifiedDirection;
	int shout_ticks;
};

class Tunnelman : public AliveActor {
public:
	Tunnelman(StudentWorld *world);
	~Tunnelman();
	
	virtual void doSomething();
};
class HardcoreProtester : public Protester {
public:
	HardcoreProtester(StudentWorld* world, int id);
	~HardcoreProtester();
	virtual void doSomething();
private:
	Protester* pro;
};
class Earth : public Actor
{
public:
	Earth(int x, int y);
	~Earth();
	virtual void doSomething() { return; }
};
class Boulder : public AliveActor
{
public:
	Boulder(int x, int y, StudentWorld* world);
	~Boulder();
	virtual void doSomething();
	virtual int identifier(); //1
private:
	int m_state; //used to indicate if falling, stable, or dead
	bool isEarthUnderBoulder();
	int m_tick_life;
};
class Object : public AliveActor
{
public:
	Object(int x, int y, int id, unsigned int depth, double size, Direction direction, int health, StudentWorld* world, Tunnelman* Tunneler);
	~Object();
	Tunnelman* getTunneler() const;
private:
	Tunnelman* tunneler;
};
class Barrel : public Object
{
public:
	Barrel(int x, int y, StudentWorld* world, Tunnelman* tunneler);
	~Barrel();
	virtual void doSomething();
	virtual int identifier(); //2
	
};
class Gold : public Object
{
public:
	Gold(int x, int y, StudentWorld* world, Tunnelman *tunneler);
	Gold(int x, int y, StudentWorld* world, Tunnelman *tunneler, int ticks);
	~Gold();
	virtual int identifier(); //3
	virtual void doSomething();
private:
	int m_tick;
};
class Squirt : public Object
{
public:
	Squirt(int x, int y, Direction dir, StudentWorld* world, Tunnelman *tunneler);
	~Squirt();
	virtual void doSomething();
	void moveSquirt(Direction dir);
private:
	int lifespan;
	Direction squirt_direction;
};
class Waterpool : public Object
{
public:
	Waterpool(int x, int y, int ticklife, StudentWorld* world, Tunnelman* tunneler);
	~Waterpool();
	virtual void doSomething();
private:
	int tick_life_waterpool;
};
class Sonar :public Object
{
public:
	Sonar(StudentWorld* world, Tunnelman* tunneler, int ticklife);
	~Sonar();
	virtual void doSomething();
private:
	int tick_life_sonar;
};
#endif // ACTOR_H_
