#ifndef STUDENTWORLD_H_
#define STUDENTWORLD_H_

#include "GameWorld.h"
#include "GameConstants.h"
#include "Actor.h"
#include "GameController.h"
#include <string>
#include <iostream>
#include <cstdlib>
#include <vector>
#include <cmath>

class Actor;

class StudentWorld : public GameWorld
{
public:
	StudentWorld(std::string assetDir)
		: GameWorld(assetDir)
	{
	}
	~StudentWorld();
	virtual int init();
	virtual int move();
	virtual void cleanUp();

	void deleteDirt(int x, int y);
	bool canTunnelerMoveHere(int x, int y);
	bool isEarthHere(int x, int y);
	bool isEarthHere2(int x, int y);
	bool closeToBarrel(int x, int y);
	bool closeToGold(int x, int y);
	void deleteDead();
	bool collidingWithBarrel(int x, int y);
	bool collidingWithGold(int x, int y);
	bool interlapBoulder(int x, int y);
	void reduceBarrels();
	void increaseGold();
	void decreaseGold();
	bool getGold();
	void dropGold(int x, int y, int ticks);
	int getSquirts();
	void decreaseSquirts();
	void gotWaterPool();
	void setDisplayText();
	void killTunneler();
	int howManySonars();
	void decreaseSonar();
	void increaseSonar();
	void SonarSearch(int x, int y);
	bool hitsProtestor(int x, int y);
	bool isInTheRadius(int x, int y, int x2, int y2, int r);
	void addSquirt(int x, int y, GraphObject::Direction dir);
	void decreaseProtesters();
	bool spotsTunneler(int x, int y, GraphObject::Direction dir);
	void hurtTunneler();
	bool BoulderBonkProtester(int x, int y);
	bool ProtesterBribe(int x, int y);
	std::string makeDataAString(int level, int lives, int health, int squirts, int gold, int barrels, int sonar, int score);
private:
	int how_many_barrels;
	int how_much_gold;
	int how_many_squirts;
	int how_many_sonar;
	int maxProtesters;
	int numberProtesters;
	int waitForProtesters;
	void addBoulders();
	void addBarrels();
	void addGold();
	void addProtesters();
	void addWaterPool();
	Earth* m_earth[64][64];
	Tunnelman* Tunneler;
	std::vector<Actor*> m_actors;
	
	
};

#endif // STUDENTWORLD_H_
