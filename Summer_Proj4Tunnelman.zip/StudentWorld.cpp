#include "StudentWorld.h"
#include <string>
#include <random>
#include <vector>
#include <iomanip>
#include <cmath>
using namespace std;

GameWorld* createStudentWorld(string assetDir)
{
	return new StudentWorld(assetDir);
}
int StudentWorld::init()
{
	how_many_squirts = 5;
	how_many_sonar = 1;
	maxProtesters = min(15, (int)(2+ getLevel()));
	waitForProtesters = 250;
	numberProtesters = 0;
	Tunneler = nullptr;
	how_much_gold = 0;
	how_many_barrels = getLevel() + 2;
	if (getLevel() > 19)
	{
		how_many_barrels = 21;
	}
	for (int r = 0; r < 64; r++)
	{
		for (int c = 0; c < 64; c++)
		{
			if (c > 29 && c < 34)
			{
				if (r < 4)
				{
					m_earth[c][r] = new Earth(c, r);
				}
				else
				{
					m_earth[c][r] = nullptr;
				}
			}
			else if (r > 59)
			{
				m_earth[c][r] = nullptr;
			}
			else
			{
				m_earth[c][r] = new Earth(c, r);
			}
		}
	}
	Tunneler = new Tunnelman(this);
	addBoulders();
	addBarrels();
	addGold();
	return GWSTATUS_CONTINUE_GAME;
}
int StudentWorld::move()
{
	setDisplayText();
	if (numberProtesters == 0)
	{
		addProtesters();
		numberProtesters++;
	}
	if (numberProtesters < maxProtesters)
	{
		if (waitForProtesters > 0)
		{
			waitForProtesters--;
		}
		else 
		{
			addProtesters();
			numberProtesters++;
			waitForProtesters = 50;
		}
	}
	addWaterPool();
	for (int i = 0; i < m_actors.size(); i++)
	{
		if (m_actors.at(i)->identifier() == 4)
		{
			if (m_actors.at(i)->getTickTick() == 0)
			{
				m_actors.at(i)->doSomething();
				m_actors.at(i)->resetTick();
			}
			else
			{
				m_actors.at(i)->decreaseTick();
			}
		}
		else
			m_actors.at(i)->doSomething();
		if (how_many_barrels == 0)
		{
			GameController::getInstance().playSound(SOUND_FINISHED_LEVEL);
			return GWSTATUS_FINISHED_LEVEL;
		}
	}
	Tunneler->doSomething();
	if (Tunneler->getHealth() == 0)
	{
		decLives();
		GameController::getInstance().playSound(SOUND_PLAYER_GIVE_UP);
		return GWSTATUS_PLAYER_DIED;
	}
	deleteDead();
	return GWSTATUS_CONTINUE_GAME;
}
void StudentWorld::cleanUp()
{
	std::vector<Actor*>::iterator p = m_actors.begin();
	while (p != m_actors.end())
	{
		std::vector<Actor*>::iterator temp = p;
		delete *p;
		p = m_actors.erase(temp);

	}
	for (int r = 0; r < 64; r++)
	{
		for (int c = 0; c < 64; c++)
		{
			delete m_earth[r][c];
		}
	}
	delete Tunneler;
}
StudentWorld::~StudentWorld()
{
	for (int r = 0; r < 64; r++)
	{
		for (int c = 0; c < 64; c++)
		{
			
				delete m_earth[r][c];
				//m_earth[r][c] = nullptr;
		}
	}
	delete Tunneler;
}
void StudentWorld::addBoulders()
{
	unsigned int maxboulder = 9;
	int numBoulders = min(getLevel() / 2 + 2, maxboulder);
	for (int i = numBoulders; i > 0; i--)
	{
		int locationx = rand() % 60;
		int locationy = rand() % 37 + 20;
		while (locationx > 25 && locationx < 35)
		{
			locationx = rand() % 60;
		}
		vector<Actor*>::iterator p = m_actors.begin();
		while (p != m_actors.end())
		{
			while (isInTheRadius(locationx, locationy, (*p)->getX(), (*p)->getY(), 6))
			{
				locationx = rand() % 60;
				locationy = rand() % 37 + 20;
				while (locationx > 25 && locationx < 35)
				{
					locationx = rand() % 60;
				}
			}
			p++;
		}

		m_actors.push_back(new Boulder(locationx, locationy, this));
	}

}
void StudentWorld::deleteDirt(int x, int y)
{
	if (x >= 0 && y >= 0 && x < 64 && y < 64)
	{
		for (int j = x; j <= x + 3; j++)
		{
			for (int i = y; i <= y + 3; i++)
			{
				if (m_earth[j][i] != nullptr)
				{
					m_earth[j][i]->setVisible(false);
					GameController::getInstance().playSound(SOUND_DIG);
					//delete m_earth[j][i];
					m_earth[j][i] = nullptr;
				}
			}
		}
	}
}

bool StudentWorld::canTunnelerMoveHere(int x, int y)
{
	vector<Actor*>::iterator p = m_actors.begin();
	while (p != m_actors.end())
	{
		if ((*p)->identifier()==1)
		{
			for (int i = -3; i < 4; i++)
			{
				for (int j = -3; j < 4; j++)
				{
					if ((*p)->getX()+i == x && (*p)->getY()+j == y)
					{
						return false;
					}
				}
			}
		}
		p++;
	}
	return true;
}
bool StudentWorld::isEarthHere(int x, int y)
{
	if (m_earth[x][y] == nullptr)
	{
		return false;
	}
	return true;
}
void StudentWorld::deleteDead()
{
	std::vector<Actor*>::iterator p = m_actors.begin();
	while (p != m_actors.end())
	{
		if ((*p)->getHealth() == 0)
		{
			std::vector<Actor*>::iterator temp = p;
			delete *p;
			p = m_actors.erase(temp);
		}
		else
		{
			p++;
		}
	}

}
void StudentWorld::addBarrels()
{
	unsigned int maxbarrel = 21;
	int numBarrels = min(getLevel() + 2, maxbarrel);
	for (int i = numBarrels; i > 0; i--)
	{
		int locationx = rand() % 60;
		int locationy = rand() % 60;
		while (locationx > 25 && locationx < 35)
		{
			locationx = rand() % 60;
		}
		vector<Actor*>::iterator p = m_actors.begin();
		while (p != m_actors.end())
		{
			while (isInTheRadius(locationx, locationy, (*p)->getX(), (*p)->getY(), 6))
			{
				locationx = rand() % 60;
				locationy = rand() % 60;
				while (locationx > 25 && locationx < 35)
				{
					locationx = rand() % 60;
				}
			}
			p++;
		}

		m_actors.push_back(new Barrel(locationx, locationy, this, Tunneler));
	}
}
bool StudentWorld::closeToBarrel(int x, int y)
{
	std::vector<Actor*>::iterator p = m_actors.begin();
	while (p != m_actors.end())
	{
		if ((*p)->identifier()==2)
		{
			for (int i = -4; i < 5; i++)
			{
				for (int j = -4; j < 5; j++)
				{
					if (x + i == Tunneler->getX() && y + j == Tunneler->getY())
					{
						return true;
					}
				}
			}
		}
		p++;
	}
	return false;
}
bool StudentWorld::collidingWithBarrel(int x, int y)
{
	for (int i = -2; i < 3; i++)
	{
		for (int j = -2; j < 3; j++)
		{
			if (x + i == Tunneler->getX() && y +j ==Tunneler->getY())
			{
				return true;
			}
		}
	}
	return false;
}
void StudentWorld::reduceBarrels()
{
	how_many_barrels--;
}
string StudentWorld::makeDataAString(int level, int lives, int health, int squirts, int gold, int barrels, int sonar, int score)
{
	string s = "Level: ";
	s += std::to_string(level);
	s += " Lives: ";
	s += std::to_string(lives);
	s += " Hlth: ";
	s += std::to_string(health);
	s += "% Wtr: ";
	s += std::to_string(squirts);
	s += " Gld: ";
	s += std::to_string(gold);
	s += " Oil Left: ";
	s += std::to_string(barrels);
	s += " Sonar: ";
	s += std::to_string(sonar);
	s += " Score: ";
	stringstream p;
	p << std::setw(6) << std::setfill('0') << score;
	s += p.str();
	return s;
}
void StudentWorld::setDisplayText()
{
	int level = getLevel();
	int lives = getLives();
	int health = Tunneler->getHealth();
	int squirts = how_many_squirts;
	int gold = how_much_gold;
	int barrels = how_many_barrels;
	int sonar = how_many_sonar;
	int score = getScore();
	string s = makeDataAString(level, lives, health, squirts, gold, barrels, sonar, score);
	setGameStatText(s);
}
void StudentWorld::addGold()
{
	unsigned int maxgold= 2;
	int goldnum = max(5 - getLevel() / 2, maxgold);
	for (int i = goldnum; i > 0; i--)
	{
		int locationx = rand() % 60;
		int locationy = rand() % 58;
		while (locationx > 25 && locationx < 35)
		{
			locationx = rand() % 60;
		}
		vector<Actor*>::iterator p = m_actors.begin();
		while (p != m_actors.end())
		{
			while (isInTheRadius(locationx, locationy, (*p)->getX(), (*p)->getY(), 6))
			{
				locationx = rand() % 60;
				locationy = rand() % 58;
				while (locationx > 25 && locationx < 35)
				{
					locationx = rand() % 60;
				}
			}
			p++;
		}

		m_actors.push_back(new Gold(locationx, locationy, this, Tunneler));
	}

}
bool StudentWorld::closeToGold(int x, int y)
{
	std::vector<Actor*>::iterator p = m_actors.begin();
	while (p != m_actors.end())
	{
		if ((*p)->identifier() == 3)
		{
			for (int i = -4; i < 5; i++)
			{
				for (int j = -4; j < 5; j++)
				{
					if (x + i == Tunneler->getX() && y + j == Tunneler->getY())
					{
						return true;
					}
				}
			}
		}
		p++;
	}
	return false;
}
void StudentWorld::increaseGold()
{
	how_much_gold++;
}
void StudentWorld::decreaseGold()
{
	how_much_gold--;
}
bool StudentWorld::collidingWithGold(int x, int y)
{
	for (int i = -2; i < 3; i++)
	{
		for (int j = -2; j < 3; j++)
		{
			if (x + i == Tunneler->getX() && y + j == Tunneler->getY())
			{
				return true;
			}
		}
	}
	return false;
}
bool StudentWorld::getGold()
{
	if (how_much_gold <= 0)
	{
		return false;
	}
	return true;
}
void StudentWorld::dropGold(int x, int y, int ticks)
{
	m_actors.push_back(new Gold(x, y, this, Tunneler, ticks));
}
bool StudentWorld::isInTheRadius(int x, int y, int x2, int y2, int r)
{
	int x3 = x2 - x;
	int y3 = y2 - y;
	double distance = sqrt(pow(x3, 2) + pow(y3, 2));
	if (distance > r)
	{
		return false;
	}
	return true;
}
void StudentWorld::addProtesters()
{
	int Hardcoreprobablility = min(90, (int)(getLevel() * 10)+30);
	int chance = rand() % 100;
	if (chance < Hardcoreprobablility)
	{
		Protester *m_protester = new Protester(this, TID_HARD_CORE_PROTESTER);
		m_actors.push_back(m_protester);
	}
	else
	{
		Protester *m_protester = new Protester(this, TID_PROTESTER);
		m_actors.push_back(m_protester);
	}
}
bool StudentWorld::isEarthHere2(int x, int y)
{
	for (int i = -3; i < 4; i++)
	{
		for (int j = -3; j < 4; j++)
		{
			if (isEarthHere(x + i, y + j))
			{
				return true;
			}
		}
	}
	return false;
}
int StudentWorld::getSquirts()
{
	return how_many_squirts;
}
void StudentWorld::decreaseSquirts()
{
	how_many_squirts--;
}
void StudentWorld::addSquirt(int x, int y, GraphObject::Direction dir)
{
	if (dir == GraphObject::down)
	{
		if (isEarthHere(x, y-1)||isEarthHere(x+1, y-1)||isEarthHere(x+2,y-1))
		{
			return;
		}
	}
	else if (dir == GraphObject::up)
	{
		if (isEarthHere(x, y + 4) || isEarthHere(x + 1, y + 4) || isEarthHere(x + 2, y + 4))
		{
			return;
		}
	}
	else if (dir == GraphObject::right)
	{
		if (isEarthHere(x+4, y) || isEarthHere(x + 4, y + 1) || isEarthHere(x + 4, y + 2))
		{
			return;
		}
	}
	else if (dir == GraphObject::left)
	{
		if (isEarthHere(x - 1, y) || isEarthHere(x - 1, y + 1) || isEarthHere(x - 1, y + 2))
		{
			return;
		}
	}
	m_actors.push_back(new Squirt(x, y, dir, this, Tunneler));
}
bool StudentWorld::hitsProtestor(int x, int y)
{
	std::vector<Actor*>::iterator p = m_actors.begin();
	while (p != m_actors.end())
	{
		if ((*p)->identifier() == 4)
		{
			for (int i = 0; i < 4; i++)
			{
				for (int j = 0; j < 4; j++)
				{
					if ((*p)->getX() == x + i || (*p)->getX() + 1 == x + i || (*p)->getX() + 2 == x + i || (*p)->getX() + 3 == x + i)
					{
						if ((*p)->getY() == y+j || (*p)->getY() + 1 == y+j || (*p)->getY() + 2 == y+j)
						{
							if ((*p)->IamDone())
							{
								return false;
							}
							else
							{
								(*p)->stunMe();
								GameController::getInstance().playSound(SOUND_PROTESTER_ANNOYED);
								(*p)->getAnnoyed();
							}
							return true;
						}
					}
				}
			}
		}
		p++;
	}
	return false;
}
bool StudentWorld::interlapBoulder(int x, int y)
{
	if (x == Tunneler->getX() || x==Tunneler->getX()+1 || x==Tunneler->getX()+2 || x == Tunneler->getX() - 1 || x == Tunneler->getX() - 2)
	{
		if (y == Tunneler->getY())
		{
			return true;
		}
	}
	return false;
}
void StudentWorld::killTunneler()
{
	Tunneler->setDead();
}
void StudentWorld::decreaseProtesters()
{
	numberProtesters--;
}
bool StudentWorld::spotsTunneler(int x, int y, GraphObject::Direction dir)
{
	if (dir == GraphObject::left)
	{
		if (x == Tunneler->getX() || x-1 == Tunneler->getX() || x-1 == Tunneler->getX() || x-2 == Tunneler->getX() || x-3 == Tunneler->getX() || x-4 == Tunneler->getX())
		{
			if (y == Tunneler->getY() || y+1 == Tunneler->getY() || y+2 == Tunneler->getY() || y+3 == Tunneler->getY() || y-1 == Tunneler->getY() || y-2 == Tunneler->getY())
			{
				return true;
			}
		}
	}
	if (dir == GraphObject::right)
	{
		if (x == Tunneler->getX() || x + 1 == Tunneler->getX() || x - 1 == Tunneler->getX() || x - 2 == Tunneler->getX() || x + 3 == Tunneler->getX() || x + 4 == Tunneler->getX())
		{
			if (y == Tunneler->getY() || y + 1 == Tunneler->getY() || y + 2 == Tunneler->getY() || y + 3 == Tunneler->getY() || y - 1 == Tunneler->getY() || y - 2 == Tunneler->getY())
			{
				return true;
			}
		}
	}
	if (dir == GraphObject::down)
	{
		if (y == Tunneler->getY() || y - 1 == Tunneler->getY() || y - 2 == Tunneler->getY() || y - 3 == Tunneler->getY() || y -4 == Tunneler->getY())
		{
			if (x == Tunneler->getX() || x + 1 == Tunneler->getX() || x + 2 == Tunneler->getX() || x + 3 == Tunneler->getX() || x - 1 == Tunneler->getX() || x - 2 == Tunneler->getX())
			{
				return true;
			}
		}
	}
	if (dir == GraphObject::up)
	{
		if (y == Tunneler->getY() || y + 1 == Tunneler->getY() || y + 2 == Tunneler->getY() || y + 3 == Tunneler->getY() || y + 4 == Tunneler->getY())
		{
			if (x == Tunneler->getX() || x + 1 == Tunneler->getX() || x + 2 == Tunneler->getX() || x + 3 == Tunneler->getX() || x - 1 == Tunneler->getX() || x - 2 == Tunneler->getX())
			{
				return true;
			}
		}
	}
	return false;
}
void StudentWorld::hurtTunneler()
{
	Tunneler->takeHitTunneler();
	if (Tunneler->getHealth() <= 0)
	{
		Tunneler->setDead();
	}
}
void StudentWorld::addWaterPool()
{
	int G = rand() % (300+(getLevel()*25));
	if (G == 0)
	{
		int C = rand() % 5;
		if (C == 0)
		{
			m_actors.push_back(new Sonar(this, Tunneler, 160));
			return;
		}
		int x = rand() % 60;
		int y = rand() % 60;
		while (isEarthHere(x, y) || isEarthHere(x+1, y+1) || isEarthHere(x+2, y+2) || isEarthHere(x+3, y+3) || isEarthHere(x+3, y) || isEarthHere(x, y+3) || isEarthHere(x + 2, y+3))
		{
			x = rand() % 60;
			y = rand() % 60;
		}
		m_actors.push_back(new Waterpool(x, y, 110, this, Tunneler));
	}
	else
	{
		return;
	}
}
void StudentWorld::gotWaterPool()
{
	how_many_squirts += 5;
}
int StudentWorld::howManySonars()
{
	return how_many_sonar;
}
void StudentWorld::decreaseSonar()
{
	how_many_sonar--;
}
void StudentWorld::SonarSearch(int x, int y)
{
	std::vector<Actor*>::iterator p = m_actors.begin();
	while (p != m_actors.end())
	{
		for (int i = -8; i < 9; i++)
		{
			for (int j = -8; j < 9; j++)
			{
				if (x + i == (*p)->getX() && y + j == (*p)->getY())
				{
					(*p)->setVisible(true);
				}
			}
		}
		p++;
	}
}
void StudentWorld::increaseSonar()
{
	how_many_sonar += 2;
}
bool StudentWorld::BoulderBonkProtester(int x, int y)
{
	std::vector<Actor*>::iterator p = m_actors.begin();
	while (p != m_actors.end())
	{
		if ((*p)->identifier() == 4)
		{
			if (x == (*p)->getX() || x == (*p)->getX() + 1 || x == (*p)->getX() + 2 || x == (*p)->getX() - 1 || x == (*p)->getX() - 2)
			{
				if (y == (*p)->getY())
				{
					for (int i = 0; i < 6; i++)
					{
						(*p)->getAnnoyed();
					}

					return true;
				}
			}
		}
		p++;
	}
	return false;
}
bool StudentWorld::ProtesterBribe(int x, int y)
{
	std::vector<Actor*>::iterator p = m_actors.begin();
	while (p != m_actors.end())
	{
		if ((*p)->identifier() == 3)
		{
			for (int i = 0; i < 4; i++)
			{
				for (int j = 0; j < 4; j++)
				{
					if ((*p)->getX() == x + i || (*p)->getX() + 1 == x + i || (*p)->getX() + 2 == x + i || (*p)->getX() + 3 == x + i)
					{
						if ((*p)->getY() == y + j || (*p)->getY() + 1 == y + j || (*p)->getY() + 2 == y + j)
						{
							(*p)->setDead();
							return true;
						}
					}
				}
			}
		}
		p++;
	}
	return false;
}