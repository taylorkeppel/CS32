#include "GraphObject.h"
#include "GameController.h"
#include "Actor.h"
#include "StudentWorld.h"
#include <random>
#include <iomanip>
#include <cmath>

Actor::Actor(int x, int y, int id, unsigned int depth, double size, Direction direction, int health)
	:GraphObject(id, x, y, direction, size, depth)
{
	m_health = health;
	setVisible(true);
	ticktick = 2;
	done = false;
}
Actor::~Actor()
{

}
void Actor::takeHit()
{
	m_health--;
	m_health--;
}
void Actor::getAnnoyed()
{
	return;
}
bool Actor::isAlive()
{
	if (m_health == 0)
	{
		return false;
	}
	return true;
}
int Actor::identifier()
{
	return 0;
}
AliveActor::AliveActor(int x, int y, int id, unsigned int depth, double size, Direction direction, StudentWorld* world, int health)
	:Actor(x,y,id,depth,size,direction, health), m_world(world)
{

}
AliveActor::~AliveActor()
{

}
void Actor::setDead()
{
	m_health = 0;
}
int Actor::getHealth() const
{
	return m_health;
}
StudentWorld* AliveActor::getWorld() const
{
	return m_world;
}
Earth::Earth(int x, int y)
	:Actor(x,y,TID_EARTH, 3, .25, right, 100)
{

}
Earth::~Earth()
{
}
Object::Object(int x, int y, int id, unsigned int depth, double size, Direction direction, int health, StudentWorld* world, Tunnelman* tunneler)
	:AliveActor(x, y, id, depth, size, direction, world, health)
{

}
Object::~Object()
{

}
Tunnelman* Object::getTunneler() const
{
	return tunneler;
}
Tunnelman::Tunnelman(StudentWorld* world)
	:AliveActor(30, 60, TID_PLAYER, 0, 1.0, right, world, 100)
{

}
Tunnelman::~Tunnelman()
{}

void Tunnelman::doSomething()
{
	getWorld()->deleteDirt(getX(), getY());

		int ch;
		if (getWorld()->getKey(ch) == true)
		{
			switch (ch)
			{
			case KEY_PRESS_DOWN:
				{
					if (getDirection() == down)
					{
						if (getY() > 1 && getY() <= 60)
						{
						   if(getWorld()->canTunnelerMoveHere(getX(), getY()-1))
							moveTo(getX(), getY() - 1);
						   else
						   moveTo(getX(), getY());
						}
						else
						{
							moveTo(getX(), getY());
						}
					}
					else
					{
						setDirection(down);
					}
					break;
				}
			case KEY_PRESS_UP:
			{
				if (getDirection() == up)
				{
					if (getY() >= 0 && getY() < 60)
					{
						if (getWorld()->canTunnelerMoveHere(getX(), getY() + 1))
						moveTo(getX(), getY() + 1);
						else
						{
							moveTo(getX(), getY());
						}
					}
					else
					{
						moveTo(getX(), getY());
					}
				}
				else
				{
					setDirection(up);
				}
				break;
			}
			case KEY_PRESS_RIGHT:
			{
				if (getDirection() == right)
				{
					if (getX() >= 0 && getX() < 60)
					{
						if(getWorld()->canTunnelerMoveHere(getX()+1, getY()))
						moveTo(getX() + 1, getY());
						else
						{
							moveTo(getX(), getY());
						}
					}
					else
					{
						moveTo(getX(), getY());
					}
				}
				else
				{
					setDirection(right);
				}
				break;
			}
			case KEY_PRESS_LEFT:
			{
				if (getDirection() == left)
				{
					if (getX() > 0 && getX() <= 64)
					{
						if (getWorld()->canTunnelerMoveHere(getX() - 1, getY()))
						moveTo(getX() - 1, getY());
						else
						{
							moveTo(getX(), getY());
						}
					}
					else
					{
						moveTo(getX(), getY());
					}
				}
				else
				{
					setDirection(left);
				}
				break;
			}
			case KEY_PRESS_TAB:
			{
				if (getWorld()->getGold())
				{
					getWorld()->dropGold(getX(), getY(), 100);
					getWorld()->decreaseGold();
				}
				break;
			}
			case KEY_PRESS_SPACE:
			{
				if (getWorld()->getSquirts() > 0)
				{
					GameController::getInstance().playSound(SOUND_PLAYER_SQUIRT);
					getWorld()->addSquirt(getX(), getY(), getDirection());
					getWorld()->decreaseSquirts();
				}
				break;
			}
			case KEY_PRESS_ESCAPE:
			{
				setDead();
				break;
			}
			case 'z':
			case 'Z':
			{
				if (getWorld()->howManySonars() > 0)
				{
					GameController::getInstance().playSound(SOUND_SONAR);
					getWorld()->SonarSearch(getX(), getY());
					getWorld()->decreaseSonar();
				}
			}
		}
	}
}
Boulder::Boulder(int x, int y, StudentWorld* world)
	:AliveActor(x, y, TID_BOULDER, 1, 1.0, right, world, 100), m_state(0), m_tick_life(30)
{
	world->deleteDirt(x, y);
}
int Boulder::identifier()
{
	return 1;
}
bool Boulder::isEarthUnderBoulder()
{
	if (getWorld()->isEarthHere(getX(), getY() - 1)) 
	{
		return false;
	}
	else
	{
		if (getWorld()->isEarthHere(getX() + 1, getY() - 1))
		{
			return false;
		}
		else
		{
			if (getWorld()->isEarthHere(getX() + 2, getY() - 1))
			{
				return false;
			}
			else
			{
				if (getWorld()->isEarthHere(getX() + 3, getY() - 1))
				{
					return false;
				}
			}

		}
	}
	return true;
}
void Boulder::doSomething()
{
	if (!isAlive()) return;

	if (m_state == 0)
	{
		if (isEarthUnderBoulder() == true)
		{
			m_state = 1;
		}
	}
	else if (m_state == 1)
	{
		if (m_tick_life <= 0)
		{
			m_state = 2;
			GameController::getInstance().playSound(SOUND_FALLING_ROCK);
		}
		else
		{
			m_tick_life--;
		}
	}
	else if(m_state== 2)
	{
		if (isEarthUnderBoulder())
		{
			moveTo(getX(), getY() - 1);
			if (getWorld()->interlapBoulder(getX(), getY()))
			{
				getWorld()->killTunneler();
			}
			if (getWorld()->BoulderBonkProtester(getX(), getY()))
			{
				getWorld()->increaseScore(250);
			}
		}
		else
		{
			setDead();
			setVisible(false);
		}
	}
}
Boulder::~Boulder()
{

}
Barrel::Barrel(int x, int y, StudentWorld* world, Tunnelman* tunneler)
	:Object(x, y, TID_BARREL, 2, 1.0, right, 100, world, tunneler)
{
	setVisible(false);
}
Barrel::~Barrel()
{

}

int Barrel::identifier() 
{
	return 2;
}
void Barrel::doSomething()
{
	if (!isAlive()) return;

	if (getWorld()->closeToBarrel(getX(), getY()))
	{
		setVisible(true);
	}
	if (getWorld()->collidingWithBarrel(getX(), getY()))
	{
		setVisible(false);
		GameController::getInstance().playSound(SOUND_FOUND_OIL);
		getWorld()->increaseScore(1000);
		setDead();
		getWorld()->reduceBarrels();
	}
	return;
}
Gold::Gold(int x, int y, StudentWorld* world, Tunnelman* tunneler)
	:Object(x, y, TID_GOLD, 2, 1.0, right, 100, world, tunneler)
{
	setVisible(false);
	m_tick = 0;
}
Gold::Gold(int x, int y, StudentWorld* world, Tunnelman* tunneler, int ticks)
	:Object(x, y, TID_GOLD, 2, 1.0, right, 100, world, tunneler)
{
	setVisible(true);
	m_tick = ticks;
}
Gold::~Gold()
{

}
int Gold::identifier()
{
	return 3;
}
void Gold::doSomething()
{
	if (!isAlive()) return;
	if (m_tick > 0)
	{
		m_tick--;
		if (m_tick == 0)
		{
			setVisible(false);
			setDead();
		}
		return;
	}
	if (getWorld()->closeToGold(getX(), getY()))
	{
		setVisible(true);
	}
	if (getWorld()->collidingWithGold(getX(), getY()))
	{
		setVisible(false);
		GameController::getInstance().playSound(SOUND_GOT_GOODIE);
		setDead();
		getWorld()->increaseScore(10);
		getWorld()->increaseGold();
	}
	return;
}
Protester::Protester(StudentWorld *world, int id)
	:AliveActor(60, 60, id, 0, 1.0, left, world, 9)
{
	m_state = 0;
	leaveTheEarth = false;
	howLongShouldIDoThis = 30;
	StartUp = true;
	dir = randomDirection();
	shout_ticks = 0;
}
Protester::~Protester()
{}
int Protester::howManySquaresLeft()
{
	int randomnum = rand() % 40;
	return randomnum;
}
void Protester::doSomething()
{
	if (leaveTheEarth == true)
	{
		if (getX() == 60 && getY() == 60)
		{
			setDead();
			getWorld()->decreaseProtesters();
		}
		if (getY() == 60)
		{
			setDirection(right);
			takeSteps(right);
		}
		else
		{
			setDirection(up);
			takeSteps(up);
		}
		return;
	}
	if (getWorld()->ProtesterBribe(getX(), getY()))
	{
		GameController::getInstance().playSound(SOUND_PROTESTER_FOUND_GOLD);
		leaveTheEarth = true;
	}
	if (getWorld()->spotsTunneler(getX(), getY(), getDirection()))
	{
		if (shout_ticks <= 0)
		{
			GameController::getInstance().playSound(SOUND_PROTESTER_YELL);
			getWorld()->hurtTunneler();
			shout_ticks = 20;
		}
		else
		{
			shout_ticks--;
		}
		return;
	}
	if (StartUp)
	{
		if (howLongShouldIDoThis < 1)
		{
			StartUp = false;
			howLongShouldIDoThis = howManySquaresLeft();
		}
		else
		{
			takeSteps(left);
			howLongShouldIDoThis--;
		}
		shout_ticks--;
	}
	else
	{
		if (howLongShouldIDoThis < 1)
		{
			howLongShouldIDoThis = howManySquaresLeft();
			dir = randomDirection();
		}
		else 
		{
			
			if (isValidStep(dir))
			{
				setDirection(dir);
				takeSteps(dir);
				howLongShouldIDoThis--;
			}
			else
			{
				if (getWorld()->isEarthHere(getX(), getY() - 1) == false)
				{
					if (getWorld()->isEarthHere(getX() + 1, getY() - 1) == false)
					{
						if (getWorld()->isEarthHere(getX() + 2, getY() - 1) == false)
						{
							if (getWorld()->isEarthHere(getX() + 3, getY() - 1) == false)
							{
								dir = GraphObject::down;
								//setDirection(dir);
								//howLongShouldIDoThis = howManySquaresLeft();
								if (isValidStep(dir))
								{
									setDirection(dir);
									takeSteps(dir);
									howLongShouldIDoThis--;
								}
								return;
							}
						}
					}
				}
				howLongShouldIDoThis = howManySquaresLeft();
				dir = randomDirection();
			}
		}
		shout_ticks--;
	}
	return;
}
void Protester::takeSteps(Direction dir)
{
		if (dir == down)
		{
			moveTo(getX(), getY() - 1);
		}
		if (dir == up)
		{
			moveTo(getX(), getY() + 1);
		}
		if (dir == right)
		{
			moveTo(getX() + 1, getY());
		}
		if (dir == left)
		{
			moveTo(getX() - 1, getY());
		}
}
bool Protester::isValidStep(Direction dir)
{
	if (dir == down)
	{
		if (getWorld()->isEarthHere(getX(), getY() - 1) || getWorld()->isEarthHere(getX()+1, getY() - 1) || getWorld()->isEarthHere(getX()+2, getY() - 1) || getWorld()->isEarthHere(getX()+3, getY() - 1))
		{
			return false;
		}
		if (getY() - 1 < 0)
		{
			return false;
		}
	}
	if (dir == up)
	{
		if (getWorld()->isEarthHere(getX(), getY() + 4) || getWorld()->isEarthHere(getX() + 1, getY() + 4) || getWorld()->isEarthHere(getX() + 2, getY() + 4) || getWorld()->isEarthHere(getX() + 3, getY() + 4))
		{
			return false;
		}
		if (getY() + 1 > 60)
		{
			return false;
		}
	}
	if (dir == right)
	{
		if (getWorld()->isEarthHere(getX() + 4, getY())|| getWorld()->isEarthHere(getX() + 4, getY()+1) || getWorld()->isEarthHere(getX() + 4, getY()+2) || getWorld()->isEarthHere(getX() + 4, getY()+3))
		{
			return false;
		}
		if (getX() + 1 > 60)
		{
			return false;
		}
	}
	if (dir == left)
	{
		if (getWorld()->isEarthHere(getX() -1, getY()) || getWorld()->isEarthHere(getX() - 1, getY() + 1) || getWorld()->isEarthHere(getX()-1, getY() + 2) || getWorld()->isEarthHere(getX() - 1, getY() + 3))
		{
			return false;
		}
		if (getX() - 1 < 0)
		{
			return false;
		}
	}
	return true;
}
GraphObject::Direction Protester::randomDirection()
{
	int num = rand() % 4;
	if (num == 0)
	{
		return down;
	}
	if (num == 1)
	{
		return up;
	}
	if (num == 2)
	{
		return right;
	}
	if (num == 3)
	{
		return left;
	}
	return down;
}
int Protester::identifier()
{
	return 4;
}
void Actor::stunMe()
{
	ticktick = 85;
}
int Actor::getTickTick()
{
	return ticktick;
}
void Actor::resetTick()
{
	ticktick = 2;
}
void Actor::decreaseTick()
{
	ticktick--;
}
Squirt::Squirt(int x, int y, Direction dir, StudentWorld *world, Tunnelman *tunneler)
	:Object(x, y, TID_WATER_SPURT, 1, 1.0, dir, 10, world, tunneler)
{
	lifespan = 6;
	squirt_direction = dir;
}
Squirt::~Squirt()
{}
void Squirt::doSomething()
{
	if (lifespan > 0)
	{
		moveSquirt(squirt_direction);
		lifespan--;
	}
	else
	{
		setDead();
	}
	return;
}
void Squirt::moveSquirt(Direction dir)
{
	if (dir == down)
	{
		if (getWorld()->isEarthHere(getX(), getY() - 1) || getWorld()->isEarthHere(getX() + 1, getY() - 1) || getWorld()->isEarthHere(getX() + 2, getY() - 1))
		{
			return;
		}
		moveTo(getX(), getY() - 1);
		if (getWorld()->hitsProtestor(getX(), getY()))
		{
			GameController::getInstance().playSound(SOUND_PROTESTER_ANNOYED);
			setDead();
			return;
		}
	}
	if (dir == up)
	{
		if (getWorld()->isEarthHere(getX(), getY() +4) || getWorld()->isEarthHere(getX() + 1, getY() +4) || getWorld()->isEarthHere(getX() + 2, getY() +4))
		{
			return;
		}
		moveTo(getX(), getY() +1);
		if (getWorld()->hitsProtestor(getX(), getY()))
		{
			GameController::getInstance().playSound(SOUND_PROTESTER_ANNOYED);
			setDead();
			return;
		}
	}
	if (dir == right)
	{
		if (getWorld()->isEarthHere(getX()+4, getY()) || getWorld()->isEarthHere(getX() + 4, getY() + 1) || getWorld()->isEarthHere(getX() + 4, getY() + 2))
		{
			return;
		}
		moveTo(getX() + 1, getY());
		if (getWorld()->hitsProtestor(getX(), getY()))
		{
			GameController::getInstance().playSound(SOUND_PROTESTER_ANNOYED);
			setDead();
			return;
		}
	}
	if (dir == left)
	{
		if (getWorld()->isEarthHere(getX() -1, getY()) || getWorld()->isEarthHere(getX() -1, getY() + 1) || getWorld()->isEarthHere(getX() -1, getY() + 2))
		{
			return;
		}
		moveTo(getX() - 1, getY());
		if (getWorld()->hitsProtestor(getX(), getY()))
		{
			setDead();
			return;
		}
	}
	return;
}
void Protester::getAnnoyed()
{
	takeHit();
	if (getHealth() <= 0)
	{
		GameController::getInstance().playSound(SOUND_PROTESTER_GIVE_UP);
		changeDone();
		resetTick();
		leaveTheEarth = true;
		StartUp = false;
	}
}
int Protester::mStateGetter()
{
	return m_state;
}
bool Actor::IamDone()
{
	return done;
}
void Actor::changeDone()
{
	done = true;
}
HardcoreProtester::HardcoreProtester(StudentWorld* world, int id)
	:Protester(world, id)
{

}
HardcoreProtester::~HardcoreProtester()
{}
void Actor::takeHitTunneler()
{
	m_health -= 20;
}
Waterpool::Waterpool(int x, int y, int ticklife, StudentWorld* world, Tunnelman* tunneler)
	:Object(x, y, TID_WATER_POOL, 2, 1.0, right, 100, world, tunneler)
{
	tick_life_waterpool = ticklife;
	setVisible(true);
}
Waterpool::~Waterpool()
{}
void Waterpool::doSomething()
{
	if (tick_life_waterpool <= 0)
	{
		setDead();
	}
	if (getWorld()->collidingWithBarrel(getX(), getY()))
	{
		setDead();
		getWorld()->gotWaterPool();
		GameController::getInstance().playSound(SOUND_GOT_GOODIE);
		getWorld()->increaseScore(100);
	}
	else
	{
		tick_life_waterpool--;
	}
}
Sonar::Sonar(StudentWorld* world, Tunnelman* tunneler, int ticklife)
	:Object(0, 60, TID_SONAR, 2, 1.0, right, 100, world, tunneler)
{
	tick_life_sonar = ticklife;
}
Sonar::~Sonar()
{}
void Sonar::doSomething()
{
	if (tick_life_sonar <= 0)
	{
		setDead();
	}
	if (getWorld()->collidingWithBarrel(getX(), getY()))
	{
		setDead();
		getWorld()->gotWaterPool();
		getWorld()->increaseSonar();
		GameController::getInstance().playSound(SOUND_GOT_GOODIE);
		getWorld()->increaseScore(75);
	}
	else
	{
		tick_life_sonar--;
	}
}
void HardcoreProtester::doSomething()
{
	pro->doSomething();
}