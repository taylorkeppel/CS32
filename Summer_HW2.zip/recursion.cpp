#include <iostream>
#include <string>
#include <queue>
#include <stack>
#include <cassert>
using namespace std;

int prod(unsigned int n, unsigned int m)
{
	if (m == 0) //base case where m is the number we subtract from
	{
		return 0;
	}
	int part1 = n; //always n
	int part2 = prod(n, m - 1); //you're gonna add n for this many times (until m is 0)
	return part1 + part2; //returns the sum of all those recursions

}

int numberOfDigits(int num, int digit)
{
	if (num == 0) //base case 1 where the number is 0 (choose the 0 route)
	{
		return 0;
	}
	
    if (num == digit) //whenever the number is equal to the digit we want to get its a 1 count
	{
		return 1;
	}
	int part1 = num % 10;
	if (part1 == digit) //clever way to get last digit
	{
		return 1 + numberOfDigits(num/10, digit); //adds one and gets rid of last digit
	}
	return numberOfDigits(num / 10, digit); //doesn't add one and still clears the last digit
}

string doubleDouble(string n)
{
	int m = n.size(); //checks the size
	if (m <= 1) //base case of simply returning when the size is less than or equal to one (no doubles possible_
	{
		return n;
	}
	if (n.substr(0,1) == n.substr(1, 1)) //noted two in a row
	{
		n.insert(1, "2");
		n.insert(1, "2"); //placed in between
		return n.substr(0, 3) + doubleDouble(n.substr(3)); //returns the new substring with the recursion taking place right after
		
	}
	else
	{
		return n.substr(0, 1) + doubleDouble(n.substr(1)); //goes past the one without a double attached and decreases size
	}


}

string curlyFries(string str)
{
	if (str.size() == 2) //means its just two curly braces
	{
		return str;
	}
	if (str.substr(0, 1) == "{" && str.substr(str.size()-1,1) == "}") //needs it in that exact order
	{
		return str;
	}
	if (str.substr(0, 1) != "{")
	{
		return curlyFries(str.substr(1, str.size() - 1)); //slice off from front if the first char is not {
	}
	else
	{
		return curlyFries(str.substr(0, str.size() - 1)); //slicing from end
	}
	
}

bool addEmUp(const int a[], int size, int target)
{
	if (target == 0)
	{
		return true; //means we've found some numbers that add up to them
	}
	if (size == 0 && target !=0)
	{
		return false; //we've reduced size and the target still wasn't reached
	}  
	if (addEmUp(a, size - 1, target - a[size - 1])) //pathway one where the number is needed
	{
		return true; //returning true so we aren't false yet
	}
	if (addEmUp(a, size - 1, target)) //pathway two where number isn't needed
	{
		return true;
	}
	return false;
}

//PART 2

bool canWeFinish(string maze[], int nRows, int nCols,
	int sr, int sc, int er, int ec)
{
	maze[sr][sc] = '#'; //dropped a signal we've been there
	if (sr == er && sc == ec)
	{
		return true; //ultimately we ended up there
	}
	else
	{
		if (maze[sr - 1][sc] == '.')
		{
			if (canWeFinish(maze, nRows, nCols, sr - 1, sc, er, ec)) //check up
				return true; //successful
		}
		if (maze[sr + 1][sc] == '.') //check down
		{
			if (canWeFinish(maze, nRows, nCols, sr + 1, sc, er, ec))
				return true;
		}
		if (maze[sr][sc - 1] == '.')//check left
		{
			if (canWeFinish(maze, nRows, nCols, sr, sc - 1, er, ec))
				return true;
		}
		if (maze[sr][sc + 1] == '.')//check right
		{
			if (canWeFinish(maze, nRows, nCols, sr, sc + 1, er, ec))
				return true;
		}
	}
	return false; //never found a path
}


/*int main() //was the testing for me
{
	cout << prod(0, 1) << endl;
	cout << prod(1, 1) << endl;
	cout << prod(10, 2) << endl;
    cout << prod(10, 11) << endl;
	cout << numberOfDigits(88885587, 8) << endl;
	cout << numberOfDigits(88885587, 1) << endl;
	cout << numberOfDigits(88885587, 7) << endl;
	cout << numberOfDigits(88885587, 5) << endl;
	cout << "New Data:" << endl;
	cout << numberOfDigits(18838, 8) <<endl;
	cout << numberOfDigits(55555, 3) << endl;
	cout << numberOfDigits(0, 0) << endl;
	string s = "ssoorry";
	cout << doubleDouble(s) << endl;
	string j;
	cout << doubleDouble(j) << endl;
	string woop = "yyuu";
	cout << doubleDouble(woop) << endl;
	string woop2 = "aaaa";
	cout << doubleDouble(woop2) << endl;
	string l = "sud{opshsu}sa";
	cout << curlyFries(l) << endl;
	string l2 = "fsr{ola}";
	cout << curlyFries(l2) << endl;
	string l3 = "{}";
	cout << curlyFries(l3) << endl;
	string l4 = "{ag}ijdisj";
	cout << curlyFries(l4) << endl;
	int arr[5] = {2, 4, 8, 7, 9};
	assert(addEmUp(arr, 5, 11)== true);
	assert(addEmUp(arr, 5, 10) == true);
	assert(addEmUp(arr, 5, 2) == true);
	assert(addEmUp(arr, 5, 0) == true);
	assert(addEmUp(arr, 5, 23) == true);
	assert(addEmUp(arr, 5, 16) == true);
	assert(addEmUp(arr, 5, 20) == true);
	assert(addEmUp(arr, 5, 40) == false);
	assert(addEmUp(arr, 5, 3) == false);
	int arr2[2] = { 2, 40};
	assert(addEmUp(arr2, 2, 2) == true);
	assert(addEmUp(arr2, 2, 0) == true);
	assert(addEmUp(arr2, 2, 42) == true);
	assert(addEmUp(arr2, 2, 32) == false);
	int arr3[2] = { -2, -40 };
	assert(addEmUp(arr3, 2, -42) == true);
	assert(addEmUp(arr3, 2, 2) == false);
	cout << "all done!" << endl;
	string maze[10] = {
 "XXXXXXXXXX",
 "X.......@X",
 "XX@X@@.XXX",
 "X..X.X...X",
 "X..X...@.X",
 "X....XXX.X",
 "X@X....XXX",
 "X..XX.XX.X",
 "X...X....X",
 "XXXXXXXXXX"
	};

	if (canWeFinish(maze, 10, 10, 6, 4, 1, 1))
		cout << "Solvable!" << endl;
	else
		cout << "Out of luck!" << endl;
	if (canWeFinish(maze, 10, 10, 8, 1, 1, 1) == false)
	{
		cout << "Out of luck!" << endl;
	}
	return 0;

}*/