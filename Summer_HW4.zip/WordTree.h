#ifndef WORDTREE_H
#define WORDTREE_H
#include <iostream>
#include <string>
using namespace std;

typedef string IType;

struct WordNode {
	IType m_data;
	WordNode *m_left;
	WordNode *m_right;
	int frequency=1;
	// You may add additional data members and member functions
	// in WordNode
};

class WordTree {
private:
	WordNode *root;
	void deleteTree(WordNode* cur);
	void tranverseTree(WordNode *cur, int &counter) const;
	void tranverseTree2(WordNode *cur, int &counter) const;
	void useThisForPrinting(ostream &out, WordNode*cur) const;
	void copy(WordNode *cur);
	void add2(IType v, WordNode* cur);
public:
	// default constructor
	WordTree() : root(nullptr) { };

	// copy constructor
	WordTree(const WordTree& rhs);

	// assignment operator
	const WordTree& operator=(const WordTree& rhs);
	// Inserts v into the WordTree
	void add(IType v);
	// Returns the number of distinct words / nodes
	int distinctWords() const;
	// Returns the total number of words inserted, including
 // duplicate values
	int totalWords() const;

	// Prints the LinkedList
	friend ostream& operator<<(ostream &out, const WordTree&
		rhs);
	// Destroys all the dynamically allocated memory in the
	// tree
	~WordTree();
};
#endif