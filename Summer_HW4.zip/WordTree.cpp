#include "WordTree.h"

WordTree::WordTree(const WordTree& rhs)
{
	root = nullptr; //sets the root to null
	copy(rhs.root); //copy the tree over
}
void WordTree::add2(IType v, WordNode* original)
{
	if (root == nullptr) //this is exactly the same as add, but copies orignals frequency
	{
		root = new WordNode;
		root->m_data = v;
		root->m_left = nullptr;
		root->m_right = nullptr;
		return;
	}
	WordNode* cur = root;
	for (;;)
	{
		if (v == cur->m_data)
		{
			cur->frequency =original->frequency;
			return;
		}
		if (v < cur->m_data)
		{
			if (cur->m_left != nullptr)
			{
				cur = cur->m_left;
			}
			else
			{
				cur->m_left = new WordNode;
				cur = cur->m_left;
				cur->m_data = v;
				cur->frequency = original->frequency;
				cur->m_left = nullptr;
				cur->m_right = nullptr;
				return;
			}
		}
		else if (v > cur->m_data)
		{
			if (cur->m_right != NULL)
			{
				cur = cur->m_right;
			}
			else
			{
				cur->m_right = new WordNode;
				cur = cur->m_right;
				cur->m_data = v;
				cur->frequency = original->frequency;
				cur->m_left = nullptr;
				cur->m_right = nullptr;
				return;
			}
		}
	}
}
void WordTree::copy(WordNode *cur)
{
	if (cur != nullptr) //for AO and CC
	{
		add2(cur->m_data, cur); //add (with the frequencies same)
		copy(cur->m_left); //preorder does left first
		copy(cur->m_right); //only while it's not nullptr
	}
}
void WordTree::useThisForPrinting(ostream &out, WordNode*cur) const
{
	if (cur == NULL)
	{
		return; //no valuethere
	}
	useThisForPrinting(out, cur->m_left); //uses in order traversal
	cout << cur->m_data << " " << cur->frequency <<endl; //print out alphabetically
	useThisForPrinting(out, cur->m_right); //then go through right tree
}
void WordTree::deleteTree(WordNode* cur)
{
	if (cur == NULL)
		return;

	deleteTree(cur->m_left); //go through all left
	deleteTree(cur->m_right); //right

	delete cur; //delete the one where we are (recursively goes through all)

}
void WordTree::tranverseTree(WordNode* cur, int &counter) const
{
	if (cur == NULL)  	  
		return;

	counter++;      

	tranverseTree(cur->m_left, counter);    
	tranverseTree(cur->m_right, counter); //used for distinct words
}
void WordTree::tranverseTree2(WordNode* cur, int &counter) const
{
	if (cur == NULL)
		return;

	counter += cur->frequency;

	tranverseTree2(cur->m_left, counter);
	tranverseTree2(cur->m_right, counter); //used for total words
}

const WordTree& WordTree::operator=(const WordTree& rhs)
{

	if (&rhs != this)
	{
		deleteTree(root); //delete the old tree
		root = nullptr;  //set it to null
		copy(rhs.root); //copy function to get new tree
	}
	return *this; //equal to itself 
}
void WordTree::add(IType v)
{
	if (root == nullptr) //empty tree case
	{
		root = new WordNode;
		root->m_data = v;
		root->m_left = nullptr;
		root->m_right = nullptr;
		return;
	}
	WordNode* cur = root; //now we itreatively go through to add
	for (;;)
	{
		if (v == cur->m_data) //already in list
		{
			cur->frequency++; //add to occurances
			return;
		}
		if (v < cur->m_data)
		{
			if (cur->m_left != nullptr)
			{
				cur = cur->m_left; //go left
			}
			else
			{
				cur->m_left = new WordNode; //need to place on left
				cur = cur->m_left;
				cur->m_data = v;
				cur->m_left = nullptr;
				cur->m_right = nullptr;
				return;
			}
		}
		else if (v > cur->m_data)
		{
			if (cur->m_right != NULL)
			{
				cur = cur->m_right; //need to go right
			}
			else
			{
				cur->m_right = new WordNode; //place on the right
				cur = cur->m_right;
				cur->m_data = v;
				cur->m_left = nullptr;
				cur->m_right = nullptr;
				return;
			}
		}
	}
}
int WordTree::distinctWords() const
{
	int counter = 0;
	WordNode* cur = root;
	tranverseTree(cur, counter); //use function for distinct
	return counter;

}
int WordTree::totalWords() const
{
	int counter = 0;
	WordNode* cur = root;
	tranverseTree2(cur, counter); //use aux for total
	return counter;
}
WordTree::~WordTree()
{
	WordNode* cur = root;
	deleteTree(cur); //delete the entire tree pls
}
ostream& operator<<(ostream &out, const WordTree&
	rhs)
{
	WordNode *cur = rhs.root;
	rhs.useThisForPrinting(out, cur); //need to use rhs. since private function
	return out; //just needed for return value
}

