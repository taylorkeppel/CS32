#include <iostream>
#include <cassert>
#include "WordTree.h"
using namespace std;

int main()
{
	WordTree k;
	k.add("Kim");
	k.add("Kanye");
	k.add("Kanye");
	k.add("Kanye");
	k.add("Yeezus");
	k.add("Taylor");
	k.add("Abba");
	k.add("Aba");
	k.add("Zannie");
	assert(k.distinctWords() == 7);
	assert(k.totalWords() == 9);
	cout << k;
	WordTree l(k);
	cout << l;
	WordTree t;
	t.add("peppa");
	t.add("pig");
	k = t;
	cout << k;
	assert(k.distinctWords() == 2);
	assert(k.totalWords() == 2);
	WordTree w;
	w.add("Harry");
	w.add("Niall");
	w.add("Niall");
	w.add("Liam");
	w.add("Louis");
	w.add("Harry");
	w.add("Niall");
	w.add("Zayn");
	assert(w.totalWords() == 8);
	assert(w.distinctWords() == 5);
	cout << w;
	WordTree empty;
	assert(empty.distinctWords() == 0);
	assert(empty.totalWords() == 0);
	WordTree tkepp(empty);
	assert(tkepp.distinctWords() == 0);
	assert(tkepp.totalWords() == 0);
	empty = k;
	assert(empty.distinctWords() == 2);
	assert(empty.totalWords() == 2);
	//return 0;
}