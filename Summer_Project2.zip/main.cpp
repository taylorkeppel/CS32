/*#include "BballRoster.h"
#include <cassert>
using namespace std;
int main()
{

	/*BballRoster a;
	assert(a.rosterEmpty() == true);
	assert(a.howManyPlayers() == 0);
	a.signPlayer("A", "A", 21);
	a.signPlayer("A", "C", 21);
	a.signPlayer("A", "B", 21);
	a.signPlayer("A", "P", 21);
	a.signPlayer("A", "K", 21);
	a.signPlayer("D", "H", 21);
	a.signPlayer("A", "Z", 21);
	a.signPlayer("B", "A", 21);
	assert(a.signPlayer("D", "H", 21)==false);
	assert(a.playerOnRoster("Da", "H") == false);
	a.signPlayer("A", "Z", 21);
	a.signPlayer("A", "H", 21);
	a.signPlayer("D", "A", 21);
	a.signPlayer("C", "Y", 22);
	a.signPlayer("C", "Y", 22);
	a.signPlayer("A", "Y", 22);
	a.signPlayer("B", "Y", 22);
	assert(a.howManyPlayers() == 13);
	SomeType i;
	SomeType j;
	std::string s;
	std::string k;
	assert(a.playerOnRoster("B", "A") == true);
	assert(a.lookupPlayer("A", "H", i)==true && i==21);
	assert(a.rosterEmpty() == false);
	assert(a.choosePlayer(8, s, k, j) == true && s == "A" && k == "P" && j == 21);
	assert(a.choosePlayer(12, s, k, j) == true && s=="A" && k=="Z" && j==21);
	assert(a.choosePlayer(13, s, k, j) == false);
	a.signOrResign("A", "B", 10);
	a.signOrResign("Z", "Y", 19);
	a.renouncePlayer("A", "A");
	assert(a.howManyPlayers() == 13);
	a.renouncePlayer("D", "A");
	assert(a.howManyPlayers() == 12);
	a.renouncePlayer("Z", "Y");
	assert(a.howManyPlayers() == 11);
	a.renouncePlayer("A", "Z");
	assert(a.howManyPlayers() == 10);
	a.renouncePlayer("A", "Z");
	assert(a.howManyPlayers() == 10);
	BballRoster b(a);
	assert(b.howManyPlayers() == a.howManyPlayers());
	assert(b.howManyPlayers() == 10);
	assert(b.rosterEmpty() == false);
	a.signOrResign("E", "Y", 10);
	a.renouncePlayer("A", "B");
	a.dump();
	BballRoster clippers;

	clippers.signPlayer("Tyrone", "Wallace", 7);
	assert(!clippers.playerOnRoster("", ""));
	clippers.signPlayer("Kawhi", "Leonard", 5);
	clippers.signPlayer("", "", 6);
	clippers.signPlayer("Paul", "George", 4);
	assert(clippers.playerOnRoster("", ""));
	clippers.renouncePlayer("Tyrone", "Wallace");
	assert(clippers.howManyPlayers() == 3
		&& clippers.playerOnRoster("Kawhi", "Leonard")
		&& clippers.playerOnRoster("Paul", "George")
		&& clippers.playerOnRoster("", ""));
	BballRoster b101;
	b101.signPlayer("Kyrie", "Irving", 12);
	b101.signPlayer("Kevin", "Durant", 7);
	b101.signPlayer("DeAndre", "Jordan", 6);
	BballRoster b102;
	b102.signPlayer("Kevin", "Durant", 17);
	b102.signPlayer("Spencer", "Dewittle", 8);
	BballRoster b103;
	joinRosters(b101, b102, b103);
	b103.dump();
	cerr << " " << endl;
	BballRoster a101;
	BballRoster a102;
	a101.signPlayer("Kyrie", "Irving", 12);
	a101.signPlayer("Kyrie", "Durant", 7);
	a101.signPlayer("DeAndre", "Durant", 6);
	a102.signPlayer("Kyrie", "Irving", 12);
	a102.signPlayer("Kyrie", "Durant", 7);
	a102.signPlayer("DeAndre", "Durant", 6);
	checkRoster("*", "Durant", a101, a101);
	a101.dump();
	BballRoster y;
	y.signPlayer("J", "K", 2);
	y.renouncePlayer("J", "K");
	assert(y.howManyPlayers() == 0);
	assert(y.rosterEmpty() == true);
    y.dump();
	BballRoster a10;
	BballRoster a11;
	BballRoster a12;
	a12.signPlayer("Kyrie", "Irving", 12);
	a12.signPlayer("Kyrie", "Durant", 7);
	a12.signPlayer("DeAndre", "Durant", 6);
	joinRosters(a10, a11, a12);
	cerr << "hi" << endl;
	a12.dump();
	cerr << "Bye" << endl;
	BballRoster ab;
	BballRoster ac;
	BballRoster ad;
	BballRoster ae;
	ad.signPlayer("H", "Yousn", 22);
	ab.signPlayer("A", "K", 21);
	ab.signPlayer("D", "H", 21);
	ab.signPlayer("A", "Z", 21);
	ac.signPlayer("A", "K", 21);
	ac.signPlayer("D", "H", 21);
	ac.signPlayer("A", "Z", 21);
	joinRosters(ae, ad, ab);
	ab.dump();
	BballRoster pi;
	pi.signPlayer("Justin", "Trudea", 13);
	pi.signPlayer("Barack", "Obama", 9);
	BballRoster pi2;
	//pi2.signPlayer("Joe", "Biden", 22);
	string so;
	string what;
	SomeType immarockstar;
	assert(pi.choosePlayer(1, so, what, immarockstar) == true && so == "Justin" && what == "Trudea" && immarockstar == 13);
	assert(pi2.howManyPlayers() == 0);
	assert(pi.howManyPlayers() == 2);
	pi2 = pi;
	assert(pi2.howManyPlayers() == 2);
	assert(pi2.choosePlayer(1, so, what, immarockstar) == true && so == "Justin" && what == "Trudea" && immarockstar == 13);
	pi2.dump();
	pi2 = pi;
	assert(pi2.howManyPlayers() == 2);
	assert(pi2.choosePlayer(1, so, what, immarockstar) == true && so == "Justin" && what == "Trudea" && immarockstar == 13);
	pi2.dump();
	BballRoster pi4;
	pi4.signPlayer("Michelle", "Obama", 3);
	pi4.swapRoster(pi2);
	pi2.dump();
	pi4.dump();
}*/
#include "BballRoster.h"
#include <string>
#include <iostream>
#include <cassert>
using namespace std;
void test()
{
	BballRoster wgym;
	BballRoster wgym2;
	BballRoster gym;
	assert(wgym.signPlayer("Valerie", "Kondos",
		"vkondos@athletics.ucla.edu"));
	assert(wgym.signPlayer("Chris", "Waller",
		"cwaller@athletics.ucla.edu"));
	assert(wgym.howManyPlayers() == 2);
	string first, last, e;
	assert(wgym.choosePlayer(0, first, last, e)
		&& e == "vkondos@athletics.ucla.edu");
	assert(wgym.choosePlayer(1, first, last, e) &&
		(first == "Chris" && e == "cwaller@athletics.ucla.edu"));
	assert(wgym2.signPlayer("Margzetta", "Frazier", "Yay"));
	wgym2.swapRoster(wgym);
	assert(wgym.renouncePlayer("Margzetta", "Frazier"));
	assert(wgym.rosterEmpty() == true);
	assert(wgym2.signOrResign("Valerie", "Kondos", "Yay"));
	assert(wgym2.signOrResign("Katelyn", "Ohashi", "omg"));
	assert(wgym2.signOrResign("Kala", "Ohashi", "my fav"));
	assert(wgym2.signPlayer("Rahashi", "Ohashi", "Woop!"));
	assert(wgym2.signPlayer("Hola", "Ohashi", "OMGGG"));
	assert(wgym2.signPlayer("Yesenia", "Ohashi", "FRick"));
	assert(wgym2.signPlayer("Alex", "Ohashi", "OOP"));
	assert(wgym2.signPlayer("WHY", "ZZZ", "LOL"));
	assert(wgym2.howManyPlayers() == 9);
	assert(wgym2.renouncePlayer("WHY", "ZZZ"));
	assert(wgym2.signPlayer(" ", " ", "what"));
	assert(wgym2.resignPlayer(" ", " ", "I like it like that"));
	assert(wgym2.signPlayer("Zwolf", "Xenia", "oh"));
	assert(wgym2.rosterEmpty() == false);
	wgym2.dump();
	wgym.dump();
	wgym.signOrResign("o", "o", "yee");
	gym.signOrResign("ohh", "ohh", "yee");
	gym.signOrResign("Hi", "Karen", "HI KEVIN");
	BballRoster workout(gym);
	workout.dump();
	BballRoster y;
	joinRosters(gym, workout, y);
	cerr << "hi" << endl;
	y.dump();
	checkRoster("*", "*", gym, workout);
	workout.dump();
	return;
}
int main()
{
	test();
	cout << "Passed all tests" << endl;
	BballRoster lakers;
	lakers.signPlayer("LeBron", "James", "k");
	lakers.signPlayer("Anthony", "Davis", "l");
	lakers.signPlayer("Kyle", "Kuzma", "p");
	lakers.signPlayer("Boogie", "Cousins", "o");
	lakers.signPlayer("Rajon", "Rondo", "p");
	for (int n = 0; n < lakers.howManyPlayers(); n++)
	{
		string first;
		string last;
		SomeType val;
		lakers.choosePlayer(n, first, last, val);
		cout << first << " " << last << " " << val << endl;
	}
	BballRoster f;
	BballRoster d;
	d.signPlayer("H", "L", "l");
	f =d;
	return 0;
}