#include"BballRoster.h"
using namespace std;

BballRoster::BballRoster()
{
	head = nullptr; //initializing the head (not using tail)
}

BballRoster::~BballRoster()
{
	Node *p= head;
	while (p != nullptr)
	{
		Node *n = p->next;
		delete p;
		p = n; //easy way to destruct
	}
}

const BballRoster& BballRoster::operator=(const BballRoster& rhs)
{
	if (&rhs == this) //aliasing prevention
		return *this;
	else
	{
		BballRoster temp = rhs;
		swapRoster(temp); //use my own swap roster function to do a shallow copy
	}
		return *this;
}

BballRoster::BballRoster(const BballRoster& rhs)
{
	m_size = rhs.m_size; //assign the sizes to each other
	if (rhs.head == nullptr) 
		head = nullptr; //both are empty then
	else {
		head = new Node;
		head->data= rhs.head->data;
		head->first_name = rhs.head->first_name;
		head->last_name = rhs.head->last_name;
		head->prev = nullptr;
		Node *q = head; //to traverse
		Node *p = rhs.head->next; //to get data
		while (p != nullptr) {
			q->next = new Node;
			q->next->data = p->data;
			q->next->first_name = p->first_name;
			q->next->last_name = p->last_name; //insert datas
			q->next->prev = p->prev; //update the previous
			q->next->next = nullptr;
			p = p->next;
			q = q->next;
		}
	} //classic deep copy 

}

bool BballRoster::rosterEmpty() const
{
	if (m_size == 0) //asserts that no elements exist
	{
		return true;
	}
	else
		return false; //is not empty
}

int BballRoster::howManyPlayers() const
{
	return m_size; //getter for size
}

bool BballRoster::signPlayer(const std::string& firstName, const std::string&
	lastName, const SomeType& value)
{
	Node* w = head;
	if (head == nullptr) //if this is first node being inserted
	{
		m_size += 1;
		Node* p = new Node;
		p->last_name = lastName;
		p->first_name = firstName;
		p->data = value;
		p->next = head;
		head = p;
		p->prev = nullptr;
		return true;
	}
	else if (w->last_name > lastName)  //if this belongs at the start of the list
	{
		
		m_size += 1; //add the size
		Node* p = new Node;
		p->last_name = lastName;
		p->first_name = firstName;

		p->data = value;
		p->next = head;
		head = p;
		p->next->prev = p; //update previous
		p->prev = nullptr;
		return true;
	}
	else if (w->last_name == lastName)
	{
		if (w->first_name == firstName && w->last_name == lastName) //same name so don't sign
		{
			return false;
		}
		else
		{
			int counter = 0; 
			if (w->first_name < firstName) //sort by last name
			{
				counter++;
			}
			while (w->next != nullptr && w->next->first_name < firstName && w->next->last_name==lastName)
			{
				w = w->next; //move on while it's less than first name
				counter++;
			}
			if (counter == 0) //beginning of first names
			{
				m_size += 1; //add size
				Node* p = new Node;
				p->last_name = lastName;
				p->first_name = firstName;

				p->data = value;
				p->next = head;
				head = p;
				p->next->prev = p;
				p->prev = nullptr;
				return true;
			}
			if (w != nullptr) //somewhere in middle of first names
			{
				Node* p = new Node;
				p->first_name = firstName;
				p->last_name = lastName;
				p->data = value;
				p->next = w->next;
				w->next = p;
				p->prev = w;
				if (p->next != nullptr) //in case it's at the end
					p->next->prev = p;
				m_size++; //add size
				return true;
			}
		}
		return true;
	}
	else //the case when you have to keep going forward in list
	{
		while (w->next != nullptr && w->last_name < lastName)
		{
			
			if (w->next != nullptr && w->next->last_name == lastName) //found where we wanna insert
			{
				w = w->next;
				break;
			}
			w = w->next;
		}
		if (w->last_name == lastName) //handles if now the last names are equal
		{
			if (w->first_name == firstName && w->last_name == lastName)
			{
				return false;
			}
			else //same exact code as above
			{
				if (w->first_name > firstName)
				{
					w = w->prev;
					Node* p = new Node;
					p->first_name = firstName;
					p->last_name = lastName;
					p->data = value;
					p->next = w->next;
					w->next = p;
					p->prev = w;
					if (p->next != nullptr)
						p->next->prev = p;
					m_size++;
					return true;
				}
				while (w->next != nullptr && w->next->first_name < firstName && w->next->last_name == lastName)
				{
					w = w->next;
				}
				if (w != nullptr)
				{
					Node* p = new Node;
					p->first_name = firstName;
					p->last_name = lastName;
					p->data = value;
					p->next = w->next;
					w->next = p;
					p->prev = w;
					if (p->next != nullptr)
						p->next->prev = p;
					m_size++;
					return true;
				}
			}
		}
		if (w != nullptr) //last name is not the same so we just insert normally
		{
			Node* p = new Node;
			p->first_name = firstName;
			p->last_name = lastName;
			p->data = value;
			p->next = w->next;
			w->next = p;
			p->prev = w;
			if(p->next !=nullptr) //cant update next previous if last in list
			p->next->prev = p;
			m_size++;
			return true;
		}
		return true;
	}
	
}

bool BballRoster::resignPlayer(const std::string& firstName, const std::string&
	lastName, const SomeType& value)
{
	Node*p = head;
	while (p != nullptr) //looping through
	{
		if (p->first_name == firstName && p->last_name == lastName) //case to enter
		{
			p->data = value; //new value
			return true;
		}
		p = p->next;
	}
	return false; //didn't find
}

bool BballRoster::signOrResign(const std::string& firstName, const std::string&
	lastName, const SomeType& value)
{
	Node* w = head; //beware, it's the same code as insert with some minor adjustments
	if (head == nullptr)
	{
		m_size += 1;
		Node* p = new Node;
		p->last_name = lastName;
		p->first_name = firstName;
		p->data = value;
		p->next = head;
		head = p;
		p->prev = nullptr;
		return true;
	}
	else if (w->last_name > lastName)
	{

		m_size += 1;
		Node* p = new Node;
		p->last_name = lastName;
		p->first_name = firstName;

		p->data = value;
		p->next = head;
		head = p;
		p->next->prev = p;
		p->prev = nullptr;
		return true;
	}
	else if (w->last_name == lastName)
	{
		if (w->first_name == firstName && w->last_name == lastName)
		{
			w->data = value; //now, we don't remove but rather put in the new value
			return true;
		}
		else
		{
			int counter = 0;
			if (w->first_name < firstName)
			{
				counter++;
			}
			while (w->next != nullptr && w->next->first_name < firstName && w->next->last_name == lastName)
			{
				w = w->next;
				counter++;
			}
			if (counter == 0)
			{
				m_size += 1;
				Node* p = new Node;
				p->last_name = lastName;
				p->first_name = firstName;

				p->data = value;
				p->next = head;
				head = p;
				p->next->prev = p;
				p->prev = nullptr;
				return true;
			}
			if (w != nullptr)
			{
				Node* p = new Node;
				p->first_name = firstName;
				p->last_name = lastName;
				p->data = value;
				p->next = w->next;
				w->next = p;
				p->prev = w; //long boring chunk of code but you can understand if you take time to read it
				if (p->next != nullptr)
					p->next->prev = p;
				m_size++;
				return true;
			}
		}
		return true; //always returns true
	}
	else
	{
		while (w->next != nullptr && w->next->last_name < lastName)
		{
			w = w->next;
			if (w->next != nullptr && w->next->last_name == lastName)
			{
				w = w->next;
				break;
			}

		}
		if (w->last_name == lastName)
		{
			if (w->first_name == firstName && w->last_name == lastName)
			{
				w->data = value;
				return true;
			}
			else
			{
				if (w->first_name > firstName)
				{
					w = w->prev;
					Node* p = new Node;
					p->first_name = firstName;
					p->last_name = lastName;
					p->data = value;
					p->next = w->next;
					w->next = p;
					p->prev = w;
					if (p->next != nullptr)
						p->next->prev = p;
					m_size++;
					return true;
				}
				while (w->next != nullptr && w->next->first_name < firstName && w->next->last_name == lastName)
				{
					w = w->next;
				}
				if (w != nullptr)
				{
					Node* p = new Node; //allocate that data
					p->first_name = firstName;
					p->last_name = lastName;
					p->data = value;
					p->next = w->next;
					w->next = p;
					p->prev = w;
					if (p->next != nullptr)
						p->next->prev = p;
					m_size++;
					return true;
				}
			}
		}
		if (w != nullptr)
		{
			Node* p = new Node;
			p->first_name = firstName;
			p->last_name = lastName;
			p->data = value;
			p->next = w->next;
			w->next = p;
			p->prev = w;
			if (p->next != nullptr)
				p->next->prev = p;
			m_size++;
			return true; //look at those returning true ugh legends
		}
		return true;
	}
}

bool BballRoster::renouncePlayer(const std::string& firstName, const
	std::string& lastName)
{
	if (head == nullptr) //can't remove if list is empty
	{
		return false;
	}
	Node*p = head;
	if (p->next == nullptr)
	{
		delete p;
		head = nullptr;
		m_size--;
		return true; //deleting the only item of a list
	}
	while (p != nullptr)
	{
		if (p->first_name == firstName && p->last_name == lastName)
		{
			if (p == head)
			{
				Node* killme = head;
				head = killme->next;
				head->prev = nullptr; //special case fo head
				delete killme;
				m_size--;
				return true; //we did it :)
			}
		}
		else if (p->next != nullptr && p->next->first_name==firstName && p->next->last_name==lastName)
			
		{
		Node* killme = p->next;
		p->next = killme->next; //sorts around to adjust for taking out node
		if(killme->next !=nullptr) //vital for end
		killme->next->prev = killme->prev;
		delete killme;
		m_size--;
		return true;
		}
		p = p->next; //
	}
	return false; //didn't find it :(
}

bool BballRoster::playerOnRoster(const std::string& firstName, const
	std::string& lastName) const
{
	Node* p = head;
	while (p != nullptr)
	{
		if (p->first_name == firstName && p->last_name == lastName)
		{
			return true; //name is indeed on roster
		}
		p = p->next;
	}
	return false;
}

bool BballRoster::lookupPlayer(const std::string& firstName, const std::string&
	lastName, SomeType& value) const
{
	Node*p = head;
	while (p != nullptr)
	{
		if (p->first_name == firstName && p->last_name == lastName)
		{
			value = p->data; //found the player and got the stored value
			return true;
		}
		p = p->next;
	}
	return false;
}

bool BballRoster::choosePlayer(int i, std::string& firstName, std::string&
	lastName, SomeType& value) const
{
	if (i<0 || i >= m_size)
	{
		return false; //can't be a negative position or an out of range pos
	}
	if (head == nullptr)
	{
		return false; //
	}
	Node* p = head;
	int counter = 0;
	while (counter != i)
	{
		p = p->next;
		counter++; //getting to the value we need
	}
	firstName = p->first_name;
	lastName = p->last_name;
	value = p->data; //copy data
	return true; //we did it
}

void BballRoster::swapRoster(BballRoster& other)
{
	Node* temp_head = other.head; //swapity swap the heads with a temp variable
	other.head = head;
	head = temp_head;

	int temp_size = other.m_size; //don't forget the swap those sizes
	other.m_size = m_size;
	m_size = temp_size; 
}

void BballRoster::dump() const
{
	Node *j = head;
	while (j != nullptr)
	{
		cerr << j->last_name << " " << j->first_name << " " << j->data << endl;
		j = j->next; //helped me wirh debugging purposes a LOT
	}
}

bool joinRosters(const BballRoster & bbOne, const BballRoster & bbTwo,BballRoster & bbJoined)
{
	std::string j;
	std::string k;
	
	SomeType l;
	SomeType z;
	int limit = bbJoined.howManyPlayers();
	int indicator = 0;
	int counter = 0;
	int counter2 = 0;
	for (int i = 0; i < bbOne.howManyPlayers(); i++) //needed to alias handling
	{
		bbOne.choosePlayer(i, j, k, l);
		if (bbJoined.playerOnRoster(j, k)==true)
		{
			counter++;
		}
	}
	if (counter == bbOne.howManyPlayers() && counter != 0) //it's the same!
	{
		for (int i = 0; i < bbTwo.howManyPlayers(); i++)
		{
			bbTwo.choosePlayer(i, j, k, z);
			if (bbJoined.lookupPlayer(j, k, l) == true) //how we haveto handle this stuff
			{
				if (z != l)
				{
					bbJoined.renouncePlayer(j, k);
					indicator++;
				}
			}
			else
			{
				bbJoined.signPlayer(j, k, z);
			}
		}
		if (indicator != 0) //means we removed one or more things
		return false;
		return true;
	}
	for (int i = 0; i < bbTwo.howManyPlayers(); i++)
	{
		bbTwo.choosePlayer(i, j, k, l);
		if (bbJoined.playerOnRoster(j, k) ==true)
		{
			counter2++;
		}
	}
	if (counter2 == bbTwo.howManyPlayers() && counter2 != 0) //aliasing for the second parameter
	{
		for (int i = 0; i < bbOne.howManyPlayers(); i++)
		{
			bbOne.choosePlayer(i, j, k, z);
			if (bbJoined.lookupPlayer(j, k, l) == true)
			{
				if (z != l)
				{
					bbJoined.renouncePlayer(j, k);
					indicator++;
				}
			}
			else
			{
				bbJoined.signPlayer(j, k, z);
			}
		}
		if (indicator != 0)
		return false;
		return true;
	}
	for (int i = 0; i < limit; i++) //after alias handling, we get rid of the result items
	{
		bbJoined.choosePlayer(i, j, k, l);
		bbJoined.renouncePlayer(j, k);
	}
	for (int i = 0; i < bbOne.howManyPlayers(); i++)
	{
		bbOne.choosePlayer(i, j, k, l); 
		bbJoined.signPlayer(j, k, l); //add them all
	}
	for (int i = 0; i < bbTwo.howManyPlayers(); i++)
	{
		bbTwo.choosePlayer(i, j, k, z);
		if (bbJoined.lookupPlayer(j, k, l) == true)//only add them if the names arent same or values are same
		{
			if (z != l)
			{
				bbJoined.renouncePlayer(j, k);
				indicator++;
			}
		}
		else
		{
 			bbJoined.signPlayer(j, k, z);
		}
	}
	if (indicator != 0) //means we removed one or more
	{
		return false;
	}
	return true;
}

void checkRoster(const std::string& fsearch, const std::string& lsearch, const BballRoster& bbOne, BballRoster& bbResult)
{
	std::string j;
	std::string k;
	SomeType l;
	int counter=0;
	int limit = bbOne.howManyPlayers();
	for (int i = 0; i < bbOne.howManyPlayers(); i++)
	{
		if (bbOne.choosePlayer(i, j, k, l) == bbResult.choosePlayer(i, j, k, l))
		{
			counter++;
		}
	}
	if (counter == bbOne.howManyPlayers() && counter !=0) //aliasing handling but only for the one this time
	{
		if (fsearch == "*" && lsearch == "*") //just return if they need all characters since they are the same roster
		{
			return;
		}
		else if (fsearch == "*")
		{
			for (int i = 0; i < limit; i++)
			{
				bbResult.choosePlayer(i, j, k, l);
				if (lsearch != k)
					bbResult.renouncePlayer(j, k);
			}
		}
		else if (lsearch == "*")
		{
			for (int i = 0; i < limit; i++)
			{
				bbResult.choosePlayer(i, j, k, l);
				if (fsearch != j)
					bbResult.renouncePlayer(j, k);
			}
		}
		else
		{
			for (int i = 0; i < bbResult.howManyPlayers();)
			{
				bbResult.choosePlayer(i, j, k, l);
				if (fsearch != j || lsearch != k)
					bbResult.renouncePlayer(j, k);
				else
				i++;
			}
		}
		return; //returns because alias handling is over
	}
	int count = bbResult.howManyPlayers();
	for (int i = 0; i < count; i++)
	{
		bbResult.choosePlayer(i, j, k, l); //clears up all of bbresult
		bbResult.renouncePlayer(j, k);
	}
	if (bbOne.rosterEmpty() == true)
	{
		return; //makes the final roster empty too since we cleared it
	}
	if (fsearch == "*" && lsearch == "*")
	{
		for (int i = 0; i < bbOne.howManyPlayers(); i++)
		{
			bbOne.choosePlayer(i, j, k, l);
			bbResult.signPlayer(j, k, l); //add them all 
		}
	}
	else if (fsearch == "*") //wildcard!!!
	{
		for (int i = 0; i < bbOne.howManyPlayers(); i++)
		{
			bbOne.choosePlayer(i, j, k, l);
			if(lsearch == k)
			bbResult.signPlayer(j, k, l); //only add if last name matches
		}
	}
	else if (lsearch == "*")
	{
		for (int i = 0; i < bbOne.howManyPlayers(); i++)
		{
			bbOne.choosePlayer(i, j, k, l);
			if (fsearch == j)
			bbResult.signPlayer(j, k, l); //only add if the first name matches
		}
	}
	else //no wild carding here!
	{
		for (int i = 0; i < bbOne.howManyPlayers(); i++)
		{
			bbOne.choosePlayer(i, j, k, l);
			if (fsearch == j && lsearch == k)
			bbResult.signPlayer(j, k, l); //only add if they BOTH match
		}
	}
	return;
}